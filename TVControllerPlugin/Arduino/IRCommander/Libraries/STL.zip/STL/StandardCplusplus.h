#undef abs
